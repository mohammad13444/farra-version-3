<?php
class WhatsAppAPI {
    private $access_token;
    private $phone_number_id;
    private $api_url = "https://graph.facebook.com/v18.0/";
    
    public function __construct() {
        // 🚨 بعداً که API آمد، اینجا رو پر کن
        $this->access_token = "YOUR_ACCESS_TOKEN_HERE";
        $this->phone_number_id = "YOUR_PHONE_NUMBER_ID";
    }
    
    public function sendOTP($to_number, $otp_code) {
        // ⚠️ فعلاً فقط لاگ می‌کنیم، بعداً کد واقعی WhatsApp API رو جایگزین کن
        error_log("📱 OTP Sent to $to_number: $otp_code");
        
        // 🔥 کد واقعی WhatsApp Business API (بعداً فعال کن):
        /*
        $url = $this->api_url . $this->phone_number_id . "/messages";
        
        $data = [
            "messaging_product" => "whatsapp",
            "to" => "964" . ltrim($to_number, '0'), // تبدیل 07XX به 9647XX
            "type" => "template",
            "template" => [
                "name" => "otp_verification", // نام template که در Meta تعریف کردی
                "language" => ["code" => "en"],
                "components" => [
                    [
                        "type" => "body",
                        "parameters" => [
                            ["type" => "text", "text" => $otp_code]
                        ]
                    ]
                ]
            ]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->access_token,
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $http_code == 200;
        */
        
        // فعلاً همیشه true برمی‌گردونیم
        return true;
    }
}
?>
